<?php

class AutologinTest extends \PHPUnit\Framework\TestCase
{
    
}