<?php

return [
    /*
    * Set the path to the node executable
    */
    'node_path' => env('MJML_NODE_PATH', ''),
];
